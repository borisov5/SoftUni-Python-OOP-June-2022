class Employee:
    def get_fired(self):
        return 'fired...'
